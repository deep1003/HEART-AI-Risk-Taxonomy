# HEART Technical Report

This Overleaf-ready package contains the final HEART Technical Report, its complete LaTeX source, figures, tables, bibliography, and reproducibility assets. The report presents 55 validated L3 categories and 622 bilingual L4 risk cards across General AI, Agentic AI, and Physical AI. Algorithm 1 evaluates iterative consolidation, while Algorithm 2 evaluates the numerical assignment component rather than the full set of expert semantic constraints. Table 7 reports Top-1 expert-reference agreement in ascending BGE-M3 order.
