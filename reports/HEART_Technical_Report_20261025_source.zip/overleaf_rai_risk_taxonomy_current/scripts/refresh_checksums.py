#!/usr/bin/env python3
"""Refresh the existing release checksum register in place."""

from __future__ import annotations

import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REGISTER = ROOT / "checksums.sha256"


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    paths = [line.split("  ", 1)[1] for line in REGISTER.read_text(encoding="utf-8").splitlines() if "  " in line]
    algorithm2_outputs = sorted(
        path.relative_to(ROOT).as_posix()
        for path in (ROOT / "data").glob("algorithm2_55_*")
        if path.is_file()
    )
    paths = sorted(set(paths + algorithm2_outputs))
    missing = [path for path in paths if not (ROOT / path).is_file()]
    if missing:
        raise FileNotFoundError(missing)
    REGISTER.write_text("".join(f"{digest(ROOT / path)}  {path}\n" for path in paths), encoding="utf-8")
    print(f"Refreshed {len(paths)} checksums")


if __name__ == "__main__":
    main()
