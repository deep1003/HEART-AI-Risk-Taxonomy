# AI Risk Taxonomy Technical Report

This folder is an Overleaf-ready XeLaTeX project for the American-English technical report.

## Compile

1. Preserve the existing project layout; replace files at their current paths.
2. Set the compiler to **XeLaTeX**.
3. Set the project-root `main.tex` as the main document. There is no second active entry point.
4. Compile with BibTeX enabled. Overleaf handles the required sequence automatically.

Local command:

```bash
latexmk -xelatex -interaction=nonstopmode -halt-on-error main.tex
```

## Structure

- Project-root `main.tex`: title, abstract, document order, and shared formatting.
- `sections/`: Sections 1 through 8. The unused source register is not included.
- `appendix_a.tex`: complete bilingual L0-L3 hierarchy.
- `appendix_b.tex`: algorithms and validation interpretation.
- `sections/05a_algorithm_evaluation.tex`: reviewed Algorithm 1/2 comparison and sensitivity results.
- `appendix_c_mit.tex`: MIT cross-corpus replication and source-overlap limitations.
- `references.bib`: cited papers, models, standards, and governance frameworks.
- `figures/`: vector PDF figures used in the report, plus selected high-resolution PNG and figure-source files.
- `data/`: source tables for release and validation figures.
- `scripts/`: reproducible figure-generation source inherited from the audited release bundle.

The current report uses the audited 47-category, 622-card master. Historical semantic diagnostics from an earlier taxonomy version are labeled as historical and are not presented as current assignment accuracy. The compiled reference output is included as `RAI_Risk_Taxonomy_Technical_Report.pdf`.

The revised argument distinguishes taxonomy construction from application-specific failure-mode mapping. Section 6 examines hypothetical failure modes in long-term human-humanoid collaboration; it does not claim observed failure frequencies or demonstrated causal relationships. Bibliographic and writing reviews informed this revision. Historical aggregate audits cannot all be independently reproduced from the records in this package.

This reference-reviewed, public-reader revision is dated 11 October 2026 and contains 37 pages. The canonical local path is recorded in `OVERLEAF_MASTER.md` outside this bundle. Previous masters and the frozen golden set remain unchanged. Algorithm 1 is evaluated only at the iterative consolidation stage; reference agreement and semantic proximity are not objective semantic accuracy. Section 5.2 retains confirmed cache-key text and RNG-reset evidence separately from inferred restart intervals and unresolved inference history. Appendix C distinguishes the examined MIT extract from the cited original paper and records its unresolved public-version provenance.

All 49 cited records were checked against primary bibliographic information and available claim-related text. Relevant original passages were inspected for 34 references, five remained at abstract or official-introduction level, and ten ISO standards were checked only against official scope statements, not paid normative clauses. This is a bounded citation review, not verification of every paper's empirical validity or proof of standards conformity. The incomplete full-text checks concern Campello (2013), Celeux and Govaert (1992), Zhang et al. (2023), Nogueira et al. (2026), and the OWASP Agentic AI guide. These access limitations do not constitute a complete original-text audit.

The included reference PDF is the verified Overleaf output. Download and reconcile the latest online source before subsequent edits. Run the asset checksum check from this subfolder:

```bash
shasum -a 256 -c checksums.sha256
```
