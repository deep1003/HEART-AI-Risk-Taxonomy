# HEART Technical Report

Reviewed methodology and results edition. This source accompanies the current master. Expert-reference data and all prior masters are preserved. Algorithm 1 evaluates iterative consolidation; Algorithm 2 scores the numerical assignment component, not all expert semantic constraints. Partial original-source and standards-clause access limits remain.
