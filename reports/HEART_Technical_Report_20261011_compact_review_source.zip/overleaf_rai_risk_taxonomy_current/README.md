# HEART Technical Report

Compact, specialist-proofread edition. This source accompanies the current master. Expert-reference data and all prior masters are preserved. Algorithm 1 evaluates iterative consolidation; Algorithm 2 scores the numerical assignment component, not all expert semantic constraints. Table 7 reports Top-1 expert-reference agreement in ascending BGE-M3 order. The removed MIT appendix is retained only in archive/ and is not compiled. Partial original-source and standards-clause access limits remain.
