# AI Risk Taxonomy Technical Report

This folder is an Overleaf-ready XeLaTeX project for the American-English technical report.

## Compile

1. Preserve the existing project layout; replace files at their current paths.
2. Set the compiler to **XeLaTeX**.
3. Set the project-root `main.tex` as the main document. There is no second active entry point.
4. Compile with BibTeX enabled. Overleaf handles the required sequence automatically.

Local command:

```bash
latexmk -xelatex -interaction=nonstopmode -halt-on-error main.tex
```

## Structure

- Project-root `main.tex`: title, abstract, document order, and shared formatting.
- `sections/`: Sections 1 through 8. The unused source register is not included.
- `appendix_a.tex`: complete bilingual L0-L3 hierarchy.
- `appendix_b.tex`: algorithms and validation interpretation.
- `sections/05a_algorithm_evaluation.tex`: reviewed Algorithm 1/2 comparison and sensitivity results.
- `appendix_c_mit.tex`: MIT cross-corpus replication and source-overlap limitations.
- `references.bib`: cited papers, models, standards, and governance frameworks.
- `figures/`: vector PDF figures used in the report, plus selected high-resolution PNG and figure-source files.
- `data/`: source tables for release and validation figures.
- `scripts/`: reproducible figure-generation source inherited from the audited release bundle.

The current report uses the audited 47-category, 622-card master. Historical semantic diagnostics from an earlier taxonomy version are labeled as historical and are not presented as current assignment accuracy. The compiled reference output is included as `RAI_Risk_Taxonomy_Technical_Report.pdf`.

The revised argument distinguishes taxonomy construction from application-specific failure-mode mapping. Section 6 examines hypothetical failure modes in long-term human-humanoid collaboration; it does not claim observed failure frequencies or demonstrated causal relationships. Bibliographic and writing reviews informed this revision. Historical aggregate audits cannot all be independently reproduced from the records in this package.

This reviewed revision was promoted on 10 October 2026. The canonical local path is recorded in `OVERLEAF_MASTER.md` outside this bundle. The previous master and frozen golden set remain unchanged. The included PDF is the verified 42-page Overleaf compilation. Download and reconcile the latest online source before subsequent edits. Run the asset checksum check from this subfolder:

```bash
shasum -a 256 -c checksums.sha256
```
