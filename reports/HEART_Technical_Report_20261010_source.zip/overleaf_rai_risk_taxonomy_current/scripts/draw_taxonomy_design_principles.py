from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch


ROOT = Path(__file__).resolve().parents[1]
OUTPUT_PDF = ROOT / "figures" / "taxonomy_design_principles_en.pdf"
OUTPUT_PNG = ROOT / "figures" / "taxonomy_design_principles_en.png"

LIGHT_GRAY = "#ECECEC"
MID_LIGHT_GRAY = "#CFCFCF"
MID_GRAY = "#B6B6B6"
DARK_GRAY = "#969696"
ACCENT_RED = ("#F3131F", "#FF5B68")
ARROW_GRAY = "#A7A7A7"
TEXT = "#333333"
MUTED = "#5F5F5F"

plt.rcParams.update({
    "font.family": "Arial",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


def rounded_box(ax, center_x, center_y, width, height, color, label, text_color="white"):
    is_gradient = isinstance(color, tuple)
    box = FancyBboxPatch(
        (center_x - width / 2, center_y - height / 2),
        width,
        height,
        boxstyle="round,pad=0.02,rounding_size=0.08",
        linewidth=0,
        facecolor="none" if is_gradient else color,
    )
    ax.add_patch(box)
    if is_gradient:
        gradient = np.linspace(0, 1, 1024).reshape(1, -1)
        cmap = LinearSegmentedColormap.from_list("accent_red", color)
        image = ax.imshow(
            gradient,
            extent=(
                center_x - width / 2,
                center_x + width / 2,
                center_y - height / 2,
                center_y + height / 2,
            ),
            origin="lower",
            aspect="auto",
            cmap=cmap,
            interpolation="bicubic",
            zorder=box.get_zorder() - 0.1,
        )
        image.set_clip_path(box)
    ax.text(
        center_x,
        center_y,
        label,
        ha="center",
        va="center",
        fontsize=16,
        fontweight="bold",
        color=text_color,
    )


def bracket(ax, x, y_bottom, y_top, color=MUTED):
    ax.plot([x, x], [y_bottom, y_top], color=color, linewidth=1.8)
    ax.plot([x - 0.16, x], [y_top, y_top], color=color, linewidth=1.8)
    ax.plot([x - 0.16, x], [y_bottom, y_bottom], color=color, linewidth=1.8)


def bullet(ax, x, y, text_value):
    ax.text(x, y, "-", fontsize=14, fontweight="bold", color="black", va="center")
    ax.text(x + 0.25, y, text_value, fontsize=12.25, color="black", va="center")


def main():
    fig, ax = plt.subplots(figsize=(16, 7.4), facecolor="white")
    ax.set_xlim(0, 16)
    ax.set_ylim(0, 7.4)
    ax.axis("off")

    levels = [
        ("L0", "Ownership Level", 3.0, LIGHT_GRAY, TEXT),
        ("L1", "Operating Domain", 4.0, MID_LIGHT_GRAY, "white"),
        ("L2", "Risk Area", 5.0, MID_GRAY, "white"),
        ("L3", "Risk Category", 6.0, DARK_GRAY, "white"),
        ("L4", "Risk Card", 7.0, ACCENT_RED, "white"),
    ]
    y_positions = [6.45, 5.20, 3.95, 2.70, 1.45]
    for (level, label, width, color, text_color), y in zip(levels, y_positions):
        ax.text(0.12, y, level, fontsize=17, fontweight="bold", color=TEXT, va="center", ha="left")
        rounded_box(ax, 4.0, y, width, 0.78, color, label, text_color)

    bracket(ax, 7.85, 2.25, 6.85)
    bracket(ax, 7.85, 1.05, 1.85)

    ax.text(8.45, 6.55, "1  Top-down Framework Design (L0-L3)", fontsize=16, fontweight="bold")
    bullet(ax, 8.45, 6.08, "Establishes upper taxonomy axes from prior frameworks and standards")
    bullet(ax, 8.45, 5.67, "Defines the hierarchy, inclusion criteria, and accountable ownership")

    ax.add_patch(FancyArrowPatch((8.75, 5.05), (8.75, 3.48), arrowstyle="-|>", mutation_scale=22, linewidth=2.1, color=ARROW_GRAY))
    ax.add_patch(FancyArrowPatch((15.1, 3.48), (15.1, 5.05), arrowstyle="-|>", mutation_scale=22, linewidth=2.1, color=ARROW_GRAY))
    ax.text(11.93, 4.50, "3  Iterative Expert Reconciliation", fontsize=15, fontweight="bold", ha="center")
    ax.text(11.93, 4.12, "Near-MECE Boundary Review", fontsize=14, fontweight="bold", ha="center")
    ax.text(11.93, 3.73, "Versioned best-fit synthesis", fontsize=12.25, color=MUTED, ha="center")

    ax.text(8.45, 2.20, "2  Bottom-up Evidence Synthesis (L4)", fontsize=16, fontweight="bold")
    bullet(ax, 8.45, 1.72, "Formulates risk cards from papers, reports, standards, and patents")
    bullet(ax, 8.45, 1.30, "Unresolved evidence prompts expert review of upper boundaries")

    ax.text(
        0.95,
        0.40,
        "The five-level hierarchy combines governance axes, evidence-linked risk cards, and expert revision.",
        fontsize=11.25,
        color=MUTED,
    )

    fig.subplots_adjust(left=0.015, right=0.99, top=0.98, bottom=0.04)
    fig.savefig(OUTPUT_PDF, format="pdf", facecolor="white")
    fig.savefig(OUTPUT_PNG, format="png", dpi=360, facecolor="white")
    plt.close(fig)


if __name__ == "__main__":
    main()
