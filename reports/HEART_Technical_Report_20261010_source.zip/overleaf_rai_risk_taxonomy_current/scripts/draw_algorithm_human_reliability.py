#!/usr/bin/env python3
"""Draw Figure 6 using the report's coordinated red-and-gray visual system."""

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


RED = "#EF493B"
MEDIUM_GRAY = "#9EAAAC"
LIGHT_GRAY = "#CDD3D5"
TEXT = "#222222"
MUTED = "#6F6F6F"
GRID = "#E4E4E4"


def _style_axis(ax, grid_axis):
    ax.set_axisbelow(True)
    ax.grid(axis=grid_axis, color=GRID, linewidth=0.8)
    ax.spines[["top", "right"]].set_visible(False)
    ax.spines[["left", "bottom"]].set_color(MUTED)
    ax.tick_params(colors=TEXT)
    ax.xaxis.label.set_color(TEXT)
    ax.yaxis.label.set_color(TEXT)
    ax.title.set_color(TEXT)


def draw_algorithm_human_reliability(output_pdf, output_png, data_dir=None):
    algorithm = pd.DataFrame({
        "diagnostic": [
            "Top-1 containment",
            "Top-2 containment",
            "Top-3 containment",
            "Top-5 containment",
            "Stability at sigma=0.01",
            "Stability at sigma=0.05",
        ],
        "all_active_percent": [71.9, 85.3, 91.3, 95.2, 95.0, 75.0],
        "released_subset_percent": [81.6, 91.2, 94.6, 97.2, 96.0, 80.7],
    })
    intervention = pd.DataFrame({
        "stage": ["Round 2", "Round 3", "AC-19 Physical audit"],
        "rows_reviewed": [808, 629, 65],
        "rows_with_comment_or_change": [251, 30, 3],
        "reassignments": [80, 19, 2],
    })
    intervention["comment_or_change_rate"] = (
        intervention.rows_with_comment_or_change / intervention.rows_reviewed * 100
    )
    intervention["reassignment_rate"] = intervention.reassignments / intervention.rows_reviewed * 100

    if data_dir is not None:
        data_dir = Path(data_dir)
        data_dir.mkdir(parents=True, exist_ok=True)
        algorithm.to_csv(data_dir / "archived_algorithm_reliability.csv", index=False)
        intervention.to_csv(data_dir / "human_review_intervention_rates.csv", index=False)

    plt.rcParams.update({
        "font.family": ["Arial", "Liberation Sans", "DejaVu Sans"],
        "font.size": 9,
        "axes.titlesize": 12,
        "axes.labelsize": 9,
        "figure.dpi": 150,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })
    fig, axes = plt.subplots(
        1,
        2,
        figsize=(12.0, 4.9),
        gridspec_kw={"width_ratios": [1.35, 1]},
        facecolor="white",
    )

    ax = axes[0]
    x = range(len(algorithm))
    ax.bar(
        [i - 0.18 for i in x],
        algorithm.all_active_percent,
        width=0.36,
        label="All active cards",
        color=LIGHT_GRAY,
        edgecolor="white",
        linewidth=0.5,
    )
    ax.bar(
        [i + 0.18 for i in x],
        algorithm.released_subset_percent,
        width=0.36,
        label="Released subset",
        color=RED,
        edgecolor="white",
        linewidth=0.5,
    )
    ax.set_xticks(list(x), ["Top-1", "Top-2", "Top-3", "Top-5", "Agreement\n$\\sigma$ = 0.01", "Agreement\n$\\sigma$ = 0.05"])
    ax.set_ylim(0, 120)
    ax.set_ylabel("Percent")
    ax.set_title("(a) Semantic-mapping evaluation", loc="left", weight="bold")
    ax.legend(frameon=False, fontsize=8, loc="upper right")
    _style_axis(ax, "y")
    for container in ax.containers:
        ax.bar_label(container, fmt="%.1f", fontsize=7, padding=2, color=TEXT)

    ax = axes[1]
    y = range(len(intervention))
    ax.barh(
        list(y),
        intervention.reassignment_rate,
        height=0.42,
        color=RED,
        edgecolor="white",
        linewidth=0.5,
    )
    # Rows are listed top to bottom in review order; the focused Physical AI
    # review is separated from the two expert review passes by a dashed line.
    ax.set_yticks(list(y), [
        "First expert review pass",
        "Second expert review pass",
        "Physical AI boundary review",
    ])
    ax.set_xlim(0, 12)
    ax.set_xticks([0, 3, 6, 9, 12])
    ax.set_ylim(2.6, -0.6)
    ax.axhline(1.5, color=MUTED, linewidth=0.8, linestyle="--")
    ax.set_xlabel("Reassigned (% of reviewed items)")
    ax.set_title("(b) Expert-review reassignments", loc="left", weight="bold")
    _style_axis(ax, "x")
    ax.bar_label(ax.containers[0], fmt="%.1f", fontsize=8, padding=3, color=TEXT)

    fig.tight_layout()
    fig.savefig(output_pdf, format="pdf", facecolor="white", bbox_inches="tight")
    fig.savefig(output_png, format="png", dpi=600, facecolor="white", bbox_inches="tight")
    plt.close(fig)


def main():
    root = Path(__file__).resolve().parents[1]
    draw_algorithm_human_reliability(
        root / "figures" / "fig08_algorithm_human_reliability.pdf",
        root / "figures" / "fig08_algorithm_human_reliability.png",
        root / "data",
    )


if __name__ == "__main__":
    main()
