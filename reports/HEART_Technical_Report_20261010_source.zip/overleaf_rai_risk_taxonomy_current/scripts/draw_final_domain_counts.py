#!/usr/bin/env python3
"""Draw the audited L1-domain composition as a publication-ready donut chart."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Rectangle


DOMAIN_NAMES = ["General AI", "Agentic AI", "Physical AI"]
DOMAIN_COUNTS = [492, 67, 63]
DOMAIN_COLORS = ["#EF493B", "#9EAAAC", "#CDD3D5"]
CONNECTOR = "#A7A7A7"
TEXT = "#222222"
MUTED = "#7A7A7A"

plt.rcParams.update({
    "font.family": "Arial",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


def _connector(ax, wedge, elbow, square_xy):
    angle = np.deg2rad((wedge.theta1 + wedge.theta2) / 2)
    start = (0.78 * np.cos(angle), 0.78 * np.sin(angle))
    square_center = (square_xy[0] + 0.055, square_xy[1] + 0.055)
    ax.plot(
        [start[0], elbow[0], square_center[0]],
        [start[1], elbow[1], square_center[1]],
        color=CONNECTOR,
        linewidth=0.9,
        solid_capstyle="round",
        zorder=1,
    )


def draw_final_domain_counts(output_pdf, output_png, output_csv=None):
    domain = pd.DataFrame({"domain": DOMAIN_NAMES, "cards": DOMAIN_COUNTS})
    if output_csv is not None:
        domain.to_csv(output_csv, index=False)

    total = sum(DOMAIN_COUNTS)
    fig, ax = plt.subplots(figsize=(8.8, 4.6), facecolor="white")
    wedges, _ = ax.pie(
        DOMAIN_COUNTS,
        colors=DOMAIN_COLORS,
        startangle=180,
        counterclock=True,
        radius=1.0,
        wedgeprops={"width": 0.39, "edgecolor": "white", "linewidth": 2.2},
    )
    ax.set(aspect="equal", xlim=(-2.45, 2.45), ylim=(-1.35, 1.35))
    ax.axis("off")

    label_specs = {
        "General AI": {"square": (1.70, -0.01), "elbow": (1.05, -0.32), "ha": "left"},
        "Agentic AI": {"square": (-1.86, 0.52), "elbow": (-1.05, 0.50), "ha": "right"},
        "Physical AI": {"square": (-1.86, -0.52), "elbow": (-1.05, -0.48), "ha": "right"},
    }

    for name, count, color, wedge in zip(DOMAIN_NAMES, DOMAIN_COUNTS, DOMAIN_COLORS, wedges):
        spec = label_specs[name]
        square = spec["square"]
        _connector(ax, wedge, spec["elbow"], square)
        ax.add_patch(Rectangle(square, 0.11, 0.11, facecolor=color, edgecolor="none", zorder=3))

        if spec["ha"] == "left":
            text_x = square[0] + 0.20
        else:
            text_x = square[0] - 0.10
        text_y = square[1] + 0.055
        ax.text(text_x, text_y + 0.035, name, ha=spec["ha"], va="center", fontsize=12, color=TEXT)
        ax.text(
            text_x,
            text_y - 0.18,
            f"{count:,} cards ({count / total:.1%})",
            ha=spec["ha"],
            va="center",
            fontsize=10.5,
            color=MUTED,
        )

    fig.subplots_adjust(left=0.02, right=0.98, top=0.98, bottom=0.02)
    fig.savefig(output_pdf, format="pdf", facecolor="white", bbox_inches="tight")
    fig.savefig(output_png, format="png", dpi=600, facecolor="white", bbox_inches="tight")
    plt.close(fig)


def main():
    root = Path(__file__).resolve().parents[1]
    draw_final_domain_counts(
        root / "figures" / "fig04_final_domain_counts.pdf",
        root / "figures" / "fig04_final_domain_counts.png",
        root / "data" / "final_domain_counts.csv",
    )


if __name__ == "__main__":
    main()
